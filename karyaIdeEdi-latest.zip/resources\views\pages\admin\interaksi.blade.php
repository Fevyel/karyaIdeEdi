<?php

use App\Models\Testimonial;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithPagination;

new #[Layout('layouts::admin-panel')] #[Title('Interaksi')] class extends Component
{
    use WithPagination;

    /** Tab aktif: 'pending' (menunggu keputusan) atau 'approved' (sudah jadi testimoni publik). */
    public string $tab = 'pending';

    public function setTab(string $tab): void
    {
        $this->tab = in_array($tab, ['pending', 'approved'], true) ? $tab : 'pending';
        $this->resetPage();
    }

    /**
     * Setujui komentar -> tampil sebagai testimoni publik di halaman website.
     */
    public function approve(int $testimonialId): void
    {
        $testimonial = Testimonial::query()->findOrFail($testimonialId);
        $testimonial->update(['is_approved' => true]);

        session()->flash('status', 'Komentar dari '.$testimonial->customer_name.' disetujui & tampil sebagai testimoni.');
    }

    /**
     * Tolak komentar -> dihapus permanen supaya tidak menumpuk jadi sampah.
     */
    public function reject(int $testimonialId): void
    {
        $testimonial = Testimonial::query()->findOrFail($testimonialId);
        $name = $testimonial->customer_name;
        $testimonial->delete();

        session()->flash('status', 'Komentar dari '.$name.' ditolak & dihapus.');
    }

    /**
     * Cabut persetujuan testimoni yang sudah tayang (opsional, dari tab "Disetujui").
     */
    public function revoke(int $testimonialId): void
    {
        $testimonial = Testimonial::query()->findOrFail($testimonialId);
        $testimonial->update(['is_approved' => false]);

        session()->flash('status', 'Testimoni dari '.$testimonial->customer_name.' ditarik dari tampilan publik & masuk ke daftar menunggu.');
    }

    public function with(): array
    {
        $query = Testimonial::query()->with('product')->latest();

        $query = $this->tab === 'approved' ? $query->approved() : $query->pending();

        return [
            'items' => $query->paginate(8),
            'pendingCount' => Testimonial::query()->pending()->count(),
            'approvedCount' => Testimonial::query()->approved()->count(),
        ];
    }
};
?>

<div class="space-y-6">

    {{-- ================= HEADER ================= --}}
    <div>
        <h2 class="font-display text-xl font-semibold text-admin-ink sm:text-2xl">
            Interaksi Pembeli
        </h2>
        <p class="mt-1 text-sm text-admin-ink-soft">
            Tinjau komentar dari pembeli yang sudah membeli produk. Setujui untuk menampilkannya sebagai testimoni di website, atau tolak untuk menghapusnya.
        </p>
    </div>

    @if (session('status'))
        <div class="flex items-center gap-2 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm font-medium text-green-700">
            <i class="fa-solid fa-circle-check"></i>
            {{ session('status') }}
        </div>
    @endif

    {{-- ================= TABS ================= --}}
    <div class="flex gap-2 border-b border-admin-border">
        <button
            wire:click="setTab('pending')"
            class="flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-semibold transition-colors duration-200
                {{ $tab === 'pending' ? 'border-admin-accent text-admin-accent' : 'border-transparent text-admin-ink-soft hover:text-admin-ink' }}"
        >
            Menunggu Persetujuan
            @if ($pendingCount > 0)
                <span class="flex h-5 min-w-5 items-center justify-center rounded-full bg-admin-accent px-1.5 text-[11px] text-white">
                    {{ $pendingCount }}
                </span>
            @endif
        </button>
        <button
            wire:click="setTab('approved')"
            class="flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-semibold transition-colors duration-200
                {{ $tab === 'approved' ? 'border-admin-accent text-admin-accent' : 'border-transparent text-admin-ink-soft hover:text-admin-ink' }}"
        >
            Testimoni Tayang
            <span class="flex h-5 min-w-5 items-center justify-center rounded-full bg-admin-cream px-1.5 text-[11px] text-admin-ink-soft">
                {{ $approvedCount }}
            </span>
        </button>
    </div>

    {{-- ================= LIST ================= --}}
    <div class="space-y-3">
        @forelse ($items as $item)
            <div class="flex flex-col gap-4 rounded-2xl border border-admin-border bg-admin-surface p-5 shadow-sm transition-shadow duration-300 hover:shadow-md sm:flex-row sm:items-start sm:justify-between">
                <div class="flex flex-1 items-start gap-3">
                    <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-admin-cream text-sm font-semibold text-admin-accent">
                        {{ strtoupper(substr($item->customer_name, 0, 1)) }}
                    </span>
                    <div class="min-w-0 flex-1">
                        <div class="flex flex-wrap items-center gap-x-2 gap-y-1">
                            <p class="text-sm font-semibold text-admin-ink">{{ $item->customer_name }}</p>
                            @if ($item->product)
                                <span class="text-xs text-admin-ink-soft">membeli</span>
                                <span class="text-xs font-medium text-admin-accent">{{ $item->product->name }}</span>
                            @endif
                        </div>

                        @if ($item->rating)
                            <div class="mt-1 flex items-center gap-0.5">
                                @for ($i = 1; $i <= 5; $i++)
                                    <i class="fa-solid fa-star text-[11px] {{ $i <= $item->rating ? 'text-admin-gold' : 'text-admin-border' }}"></i>
                                @endfor
                            </div>
                        @endif

                        <p class="mt-2 text-sm leading-relaxed text-admin-ink-soft">
                            {{ $item->comment }}
                        </p>

                        <p class="mt-2 text-[11px] text-admin-ink-soft">
                            {{ $item->created_at->translatedFormat('d M Y, H:i') }}
                        </p>
                    </div>
                </div>

                <div class="flex shrink-0 items-center gap-2 sm:flex-col sm:items-stretch">
                    @if ($tab === 'pending')
                        <button
                            wire:click="approve({{ $item->id }})"
                            wire:confirm="Setujui komentar ini sebagai testimoni publik?"
                            class="inline-flex items-center justify-center gap-1.5 rounded-full bg-admin-accent px-4 py-2 text-xs font-semibold text-white transition-all duration-300 hover:bg-admin-accent-strong"
                        >
                            <i class="fa-solid fa-check"></i>
                            Setujui
                        </button>
                        <button
                            wire:click="reject({{ $item->id }})"
                            wire:confirm="Tolak & hapus permanen komentar ini?"
                            class="inline-flex items-center justify-center gap-1.5 rounded-full border border-red-200 px-4 py-2 text-xs font-semibold text-red-600 transition-all duration-300 hover:bg-red-50"
                        >
                            <i class="fa-solid fa-xmark"></i>
                            Tolak
                        </button>
                    @else
                        <button
                            wire:click="revoke({{ $item->id }})"
                            wire:confirm="Tarik testimoni ini dari tampilan publik?"
                            class="inline-flex items-center justify-center gap-1.5 rounded-full border border-admin-border px-4 py-2 text-xs font-semibold text-admin-ink-soft transition-all duration-300 hover:bg-admin-cream"
                        >
                            <i class="fa-solid fa-rotate-left"></i>
                            Tarik dari Tayang
                        </button>
                    @endif
                </div>
            </div>
        @empty
            <div class="rounded-2xl border border-dashed border-admin-border bg-admin-surface px-5 py-12 text-center">
                <i class="fa-solid fa-comment-slash mb-3 text-2xl text-admin-ink-soft"></i>
                <p class="text-sm font-medium text-admin-ink">
                    {{ $tab === 'pending' ? 'Tidak ada komentar yang menunggu persetujuan.' : 'Belum ada testimoni yang tayang.' }}
                </p>
            </div>
        @endforelse
    </div>

    @if ($items->hasPages())
        <div>
            {{ $items->links() }}
        </div>
    @endif
</div>
