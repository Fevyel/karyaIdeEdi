<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Komentar/ulasan pembeli ("Interaksi").
 *
 * Alur:
 * - Pembeli mengirim komentar -> tersimpan dengan is_approved = false (menunggu).
 * - Admin menyetujui -> is_approved = true -> tampil sebagai testimoni publik.
 * - Admin menolak -> baris dihapus permanen (bukan disimpan sebagai status "ditolak").
 */
class Testimonial extends Model
{
    use HasFactory;

    protected $fillable = [
        'product_id',
        'customer_name',
        'rating',
        'comment',
        'is_approved',
    ];

    protected function casts(): array
    {
        return [
            'is_approved' => 'boolean',
            'rating' => 'integer',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** Komentar yang masih menunggu keputusan admin. */
    public function scopePending(Builder $query): Builder
    {
        return $query->where('is_approved', false);
    }

    /** Komentar yang sudah disetujui & tampil sebagai testimoni publik. */
    public function scopeApproved(Builder $query): Builder
    {
        return $query->where('is_approved', true);
    }
}
