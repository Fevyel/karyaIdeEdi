{{--
    ==========================================================
    SEMUA PRODUK — Homepage Karya Ide Edi
    ==========================================================
    Heading + filter kategori (pill) di kiri, link "Lihat Semua
    Produk" di kanan, grid 3 kolom kartu produk.

    - Data produk (thumbnail, nama, deskripsi, harga, harga
      diskon, kategori) diambil LANGSUNG dari tabel `products`
      lewat model App\Models\Product — sinkron dengan menu
      "Produk" di Admin Panel. Hanya produk berstatus "aktif"
      yang ditampilkan, dibatasi maksimal 3 produk terbaru
      (preview di homepage — katalog lengkap ada di link
      "Lihat Semua Produk").
    - Kartu produk (thumbnail + rating) memakai partial reusable
      partials/frontend/product-card.blade.php, supaya thumbnail
      selalu object-cover penuh & rating selalu dihitung dari
      testimonial approved di database (tidak ada hardcode).
    - Filter pill kategori & link "Lihat Semua Produk" MASIH
      belum berfungsi (href="#"), menunggu fitur katalog & filter
      sungguhan — di luar cakupan tugas ini.

    Pemakaian:
        @include('partials.frontend.products')
    ==========================================================
--}}

@php
    $productCategories = ['All', 'Chairs', 'Sofas', 'Tables', 'Lighting'];

    $products = \App\Models\Product::query()
        ->where('status', 'aktif')
        ->withCount(['testimonials as approved_testimonials_count' => fn ($query) => $query->approved()])
        ->withAvg(['testimonials as average_rating' => fn ($query) => $query->approved()], 'rating')
        ->latest()
        ->take(3)
        ->get();
@endphp

<section class="bg-white">
    <div class="mx-auto max-w-7xl px-6 py-14 sm:px-8 lg:px-10 lg:py-20">

        {{-- ============ Header: judul + filter (kiri), link (kanan) ============ --}}
        <div class="flex flex-wrap items-end justify-between gap-6">
            <div>
                <h2 class="font-display text-2xl text-[#4B3A26] sm:text-3xl">Semua Produk</h2>

                <div class="mt-4 flex flex-wrap gap-2.5">
                    @foreach ($productCategories as $index => $category)
                        <button
                            type="button"
                            title="Filter belum berfungsi"
                            @class([
                                'rounded-full px-4 py-1.5 text-xs font-medium transition-colors duration-300 sm:text-sm',
                                'bg-[#1A1A1A] text-white' => $index === 0,
                                'bg-admin-cream text-[#4B3A26] hover:bg-[#1A1A1A] hover:text-white' => $index !== 0,
                            ])
                        >
                            {{ $category }}
                        </button>
                    @endforeach
                </div>
            </div>

            <a
                href="#"
                class="group inline-flex items-center gap-2 border-b border-admin-ink/30 pb-0.5 text-sm font-medium text-[#4B3A26] transition-colors duration-300 hover:border-admin-accent hover:text-admin-accent"
            >
                Lihat Semua Produk
                <i class="fa-solid fa-arrow-right text-xs transition-transform duration-300 group-hover:translate-x-1"></i>
            </a>
        </div>

        {{-- ============ Grid produk ============ --}}
        @if ($products->isEmpty())
            <p class="mt-10 text-sm text-admin-ink-soft">Belum ada produk yang tersedia saat ini.</p>
        @else
            <div class="mt-10 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                @foreach ($products as $product)
                    @include('partials.frontend.product-card', ['product' => $product])
                @endforeach
            </div>
        @endif
    </div>
</section>
