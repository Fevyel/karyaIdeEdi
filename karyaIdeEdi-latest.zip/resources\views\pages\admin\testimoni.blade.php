<?php

use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

new #[Layout('layouts::admin-panel')] #[Title('Testimoni')] class extends Component
{
    //
};
?>

@include('partials.admin.placeholder', [
    'icon' => 'fa-quote-left',
    'heading' => 'Testimoni',
    'description' => 'Kelola tampilan testimoni yang sudah disetujui di halaman "Interaksi" agar tampil rapi di website customer.',
    'features' => [
        'Susun urutan tampil',
        'Sematkan testimoni pilihan',
        'Pratinjau di website',
    ],
])
