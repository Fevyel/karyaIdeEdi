<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    /**
     * Buat akun admin default untuk pengujian login.
     *
     * PENTING: Ganti password ini setelah login pertama kali,
     * jangan dipakai di lingkungan production.
     */
    public function run(): void
    {
        User::query()->updateOrCreate(
            ['email' => 'admin@mabel.test'],
            [
                'name' => 'Admin Toko Mabel',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
            ],
        );
    }
}