<?php

use App\Http\Controllers\Admin\LogoutController;
use Illuminate\Support\Facades\Route;

// ==========================================================
// Frontend Customer (jangan diubah/ditambah di sini dulu)
// ==========================================================
Route::view('/', 'welcome')->name('home');

// ==========================================================
// Admin Panel
// ==========================================================
Route::prefix('admin')->name('admin.')->group(function () {
    // Halaman login admin (Livewire full-page component)
    Route::livewire('/login', 'pages::admin.login')
        ->middleware('guest')
        ->name('login');

    // Placeholder setelah login. Ini BUKAN dashboard final,
    // hanya untuk membuktikan alur redirect + middleware auth berjalan.
    // Akan diganti pada tahap pembuatan Dashboard.
    Route::view('/', 'admin.dashboard-placeholder')
        ->middleware('auth')
        ->name('dashboard');

    Route::post('/logout', LogoutController::class)
        ->middleware('auth')
        ->name('logout');
});