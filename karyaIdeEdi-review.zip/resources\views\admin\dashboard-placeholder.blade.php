<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panel - {{ config('app.name', 'Laravel') }}</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="bg-gray-100 antialiased">
        <div class="min-h-screen flex items-center justify-center px-4 py-12">
            <div class="w-full max-w-sm bg-white shadow-sm border border-gray-200 rounded-lg p-6 text-center">
                <h1 class="text-lg font-semibold text-gray-800 mb-1">Login berhasil</h1>
                <p class="text-sm text-gray-500 mb-6">
                    Masuk sebagai
                    <span class="font-medium text-gray-700">{{ auth()->user()->name }}</span>
                    ({{ auth()->user()->email }})
                </p>

                <p class="text-xs text-gray-400 mb-6">
                    Halaman ini adalah placeholder sementara untuk menguji alur login,
                    session, middleware, dan logout. Dashboard admin yang sesungguhnya
                    akan dibangun pada tahap berikutnya.
                </p>

                <form method="POST" action="{{ route('admin.logout') }}">
                    @csrf
                    <button
                        type="submit"
                        class="w-full bg-gray-900 text-white text-sm font-medium rounded-md py-2.5 px-4 hover:bg-gray-700 transition"
                    >
                        Logout
                    </button>
                </form>
            </div>
        </div>
    </body>
</html>